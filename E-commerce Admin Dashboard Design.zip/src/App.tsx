import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { DashboardPage } from './components/DashboardPage';
import { ProductsPage } from './components/ProductsPage';
import { CategoriesPage } from './components/CategoriesPage';
import { OrdersPage } from './components/OrdersPage';
import { BlogPage } from './components/BlogPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} />
      
      <main className="flex-1 overflow-auto">
        {currentPage === 'dashboard' && <DashboardPage />}
        {currentPage === 'products' && <ProductsPage />}
        {currentPage === 'categories' && <CategoriesPage />}
        {currentPage === 'orders' && <OrdersPage />}
        {currentPage === 'blog' && <BlogPage />}
      </main>
    </div>
  );
}
