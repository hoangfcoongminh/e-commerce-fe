import { useState } from 'react';
import { Search, Plus, Edit2, Trash2, Eye } from 'lucide-react';

interface BlogPost {
  id: string;
  title: string;
  author: string;
  date: string;
  status: 'Published' | 'Draft';
  category: string;
  views: number;
}

const mockPosts: BlogPost[] = [
  { 
    id: 'BP001', 
    title: 'Spring/Summer 2026 Collection Launch', 
    author: 'Sarah Mitchell', 
    date: '2026-01-10', 
    status: 'Published',
    category: 'New Collections',
    views: 1243
  },
  { 
    id: 'BP002', 
    title: '5 Ways to Style Your Denim This Season', 
    author: 'Emily Johnson', 
    date: '2026-01-08', 
    status: 'Published',
    category: 'Fashion Tips',
    views: 856
  },
  { 
    id: 'BP003', 
    title: 'Behind the Scenes: Our Sustainable Fashion Journey', 
    author: 'Michael Chen', 
    date: '2026-01-05', 
    status: 'Published',
    category: 'Company News',
    views: 2134
  },
  { 
    id: 'BP004', 
    title: 'Winter Sale: Up to 50% Off Selected Items', 
    author: 'Sarah Mitchell', 
    date: '2026-01-03', 
    status: 'Published',
    category: 'Promotions',
    views: 3421
  },
  { 
    id: 'BP005', 
    title: 'The Ultimate Guide to Accessorizing', 
    author: 'Emily Johnson', 
    date: '2026-01-12', 
    status: 'Draft',
    category: 'Fashion Tips',
    views: 0
  },
  { 
    id: 'BP006', 
    title: 'Meet Our Designers: Exclusive Interview', 
    author: 'Michael Chen', 
    date: '2026-01-11', 
    status: 'Draft',
    category: 'Company News',
    views: 0
  },
];

export function BlogPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [posts] = useState<BlogPost[]>(mockPosts);

  const filteredPosts = posts.filter((post) => {
    const matchesSearch = 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || post.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl text-gray-900">Blog & Post Management</h1>
          <p className="text-gray-500 mt-1">Create and manage content for new collections and news</p>
        </div>

        <button className="flex items-center gap-2 px-4 py-2 bg-[#116E33] text-white rounded-lg hover:bg-[#0d5527] transition-colors">
          <Plus className="w-5 h-5" />
          Create New Post
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 mb-6">
        <div className="p-4 border-b border-gray-200">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search posts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#116E33]"
              />
            </div>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#116E33]"
            >
              <option value="all">All Status</option>
              <option value="Published">Published</option>
              <option value="Draft">Draft</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Title</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Author</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Category</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Date</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Views</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Status</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredPosts.map((post) => (
                <tr key={post.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <p className="text-sm text-gray-900">{post.title}</p>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">{post.author}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{post.category}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {post.views.toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-2 py-1 text-xs rounded-full ${
                      post.status === 'Published' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {post.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      {post.status === 'Published' && (
                        <button className="p-2 text-gray-600 hover:bg-gray-100 rounded transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                      )}
                      <button className="p-2 text-gray-600 hover:bg-gray-100 rounded transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredPosts.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-gray-500">No posts found matching your filters.</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-sm text-gray-500 mb-2">Total Posts</h3>
          <p className="text-2xl text-gray-900">{posts.length}</p>
          <p className="text-xs text-gray-500 mt-2">
            {posts.filter(p => p.status === 'Published').length} published
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-sm text-gray-500 mb-2">Total Views</h3>
          <p className="text-2xl text-gray-900">
            {posts.reduce((sum, post) => sum + post.views, 0).toLocaleString()}
          </p>
          <p className="text-xs text-green-600 mt-2">+15.3% from last month</p>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-sm text-gray-500 mb-2">Draft Posts</h3>
          <p className="text-2xl text-gray-900">
            {posts.filter(p => p.status === 'Draft').length}
          </p>
          <p className="text-xs text-gray-500 mt-2">Awaiting publication</p>
        </div>
      </div>
    </div>
  );
}
