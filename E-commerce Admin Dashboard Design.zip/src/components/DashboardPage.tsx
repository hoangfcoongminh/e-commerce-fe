import { useState } from 'react';
import { TrendingUp, DollarSign, ShoppingBag, Users } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const salesData = [
  { date: 'Jan 6', sales: 4200, orders: 45 },
  { date: 'Jan 7', sales: 3800, orders: 38 },
  { date: 'Jan 8', sales: 5100, orders: 52 },
  { date: 'Jan 9', sales: 4600, orders: 48 },
  { date: 'Jan 10', sales: 6200, orders: 61 },
  { date: 'Jan 11', sales: 5800, orders: 55 },
  { date: 'Jan 12', sales: 7100, orders: 68 },
];

const categoryData = [
  { category: 'Dresses', sales: 12500 },
  { category: 'Tops', sales: 9800 },
  { category: 'Pants', sales: 8600 },
  { category: 'Accessories', sales: 6400 },
  { category: 'Shoes', sales: 11200 },
];

export function DashboardPage() {
  const [dateRange, setDateRange] = useState('last7days');

  const stats = [
    {
      title: 'Total Revenue',
      value: '$48,652',
      change: '+12.5%',
      icon: DollarSign,
      color: 'bg-green-100 text-green-600',
    },
    {
      title: 'New Orders',
      value: '367',
      change: '+8.2%',
      icon: ShoppingBag,
      color: 'bg-blue-100 text-blue-600',
    },
    {
      title: 'Total Sales',
      value: '2,847',
      change: '+23.1%',
      icon: TrendingUp,
      color: 'bg-purple-100 text-purple-600',
    },
    {
      title: 'Website Traffic',
      value: '12,458',
      change: '+5.7%',
      icon: Users,
      color: 'bg-orange-100 text-orange-600',
    },
  ];

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl text-gray-900">Dashboard Overview</h1>
          <p className="text-gray-500 mt-1">Welcome back! Here's what's happening with your store.</p>
        </div>

        <select
          value={dateRange}
          onChange={(e) => setDateRange(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#116E33]"
        >
          <option value="last7days">Last 7 days</option>
          <option value="thismonth">This Month</option>
          <option value="lastmonth">Last Month</option>
          <option value="custom">Custom Range</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.title} className="bg-white p-6 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg ${stat.color} flex items-center justify-center`}>
                  <Icon className="w-6 h-6" />
                </div>
                <span className="text-sm text-green-600">{stat.change}</span>
              </div>
              <h3 className="text-gray-500 text-sm">{stat.title}</h3>
              <p className="text-2xl text-gray-900 mt-1">{stat.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h2 className="text-lg text-gray-900 mb-6">Sales Overview</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip />
              <Line type="monotone" dataKey="sales" stroke="#116E33" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h2 className="text-lg text-gray-900 mb-6">Sales by Category</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={categoryData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="category" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip />
              <Bar dataKey="sales" fill="#116E33" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg text-gray-900">Recent Orders</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Order ID</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Customer</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Date</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Total</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {[
                { id: '#ORD-001234', customer: 'Emma Wilson', date: 'Jan 12, 2026', total: '$156.00', status: 'Delivered' },
                { id: '#ORD-001233', customer: 'James Smith', date: 'Jan 12, 2026', total: '$89.50', status: 'Shipped' },
                { id: '#ORD-001232', customer: 'Sarah Johnson', date: 'Jan 11, 2026', total: '$234.00', status: 'Processing' },
                { id: '#ORD-001231', customer: 'Michael Brown', date: 'Jan 11, 2026', total: '$67.25', status: 'Pending' },
                { id: '#ORD-001230', customer: 'Lisa Davis', date: 'Jan 10, 2026', total: '$189.00', status: 'Delivered' },
              ].map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-900">{order.id}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">{order.customer}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{order.date}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">{order.total}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-2 py-1 text-xs rounded-full ${
                      order.status === 'Delivered' ? 'bg-green-100 text-green-700' :
                      order.status === 'Shipped' ? 'bg-blue-100 text-blue-700' :
                      order.status === 'Processing' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
