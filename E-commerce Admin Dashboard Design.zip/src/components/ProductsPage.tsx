import { useState } from 'react';
import { Search, Plus, Edit2, Trash2, Filter } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Product {
  id: string;
  name: string;
  price: number;
  stock: number;
  status: 'Active' | 'Draft';
  category: string;
  image: string;
}

const mockProducts: Product[] = [
  { id: 'P001', name: 'Floral Summer Dress', price: 89.99, stock: 45, status: 'Active', category: 'Dresses', image: 'woman summer dress' },
  { id: 'P002', name: 'Classic White Blouse', price: 49.99, stock: 120, status: 'Active', category: 'Tops', image: 'white blouse fashion' },
  { id: 'P003', name: 'High-Waist Denim Jeans', price: 79.99, stock: 85, status: 'Active', category: 'Pants', image: 'denim jeans fashion' },
  { id: 'P004', name: 'Leather Crossbody Bag', price: 129.99, stock: 32, status: 'Active', category: 'Accessories', image: 'leather bag fashion' },
  { id: 'P005', name: 'Silk Maxi Dress', price: 149.99, stock: 0, status: 'Draft', category: 'Dresses', image: 'maxi dress elegant' },
  { id: 'P006', name: 'Striped Cotton Top', price: 39.99, stock: 95, status: 'Active', category: 'Tops', image: 'striped shirt fashion' },
  { id: 'P007', name: 'Ankle Boots', price: 119.99, stock: 58, status: 'Active', category: 'Shoes', image: 'ankle boots fashion' },
  { id: 'P008', name: 'Wide Leg Trousers', price: 69.99, stock: 12, status: 'Active', category: 'Pants', image: 'trousers fashion' },
];

export function ProductsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [products] = useState<Product[]>(mockProducts);

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || product.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || product.status === filterStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl text-gray-900">Product Management</h1>
          <p className="text-gray-500 mt-1">Manage your fashion inventory</p>
        </div>

        <button className="flex items-center gap-2 px-4 py-2 bg-[#116E33] text-white rounded-lg hover:bg-[#0d5527] transition-colors">
          <Plus className="w-5 h-5" />
          Add New Product
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 mb-6">
        <div className="p-4 border-b border-gray-200">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#116E33]"
              />
            </div>

            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#116E33]"
            >
              <option value="all">All Categories</option>
              <option value="Dresses">Dresses</option>
              <option value="Tops">Tops</option>
              <option value="Pants">Pants</option>
              <option value="Accessories">Accessories</option>
              <option value="Shoes">Shoes</option>
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#116E33]"
            >
              <option value="all">All Status</option>
              <option value="Active">Active</option>
              <option value="Draft">Draft</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Image</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Product Name</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Price</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Stock</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Category</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Status</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredProducts.map((product) => (
                <tr key={product.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <ImageWithFallback
                      src={`https://source.unsplash.com/100x100/?${encodeURIComponent(product.image)}`}
                      alt={product.name}
                      className="w-12 h-12 object-cover rounded"
                    />
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">{product.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">${product.price.toFixed(2)}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={product.stock === 0 ? 'text-red-600' : product.stock < 20 ? 'text-orange-600' : 'text-gray-900'}>
                      {product.stock}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{product.category}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-2 py-1 text-xs rounded-full ${
                      product.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {product.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button className="p-2 text-gray-600 hover:bg-gray-100 rounded transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredProducts.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-gray-500">No products found matching your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}
