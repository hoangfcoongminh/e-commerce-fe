import { useState } from 'react';
import { Search, Eye, ChevronDown } from 'lucide-react';

interface Order {
  id: string;
  customer: string;
  date: string;
  total: number;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Canceled';
  items: number;
}

const mockOrders: Order[] = [
  { id: 'ORD-001234', customer: 'Emma Wilson', date: '2026-01-12', total: 156.00, status: 'Delivered', items: 2 },
  { id: 'ORD-001233', customer: 'James Smith', date: '2026-01-12', total: 89.50, status: 'Shipped', items: 1 },
  { id: 'ORD-001232', customer: 'Sarah Johnson', date: '2026-01-11', total: 234.00, status: 'Processing', items: 3 },
  { id: 'ORD-001231', customer: 'Michael Brown', date: '2026-01-11', total: 67.25, status: 'Pending', items: 1 },
  { id: 'ORD-001230', customer: 'Lisa Davis', date: '2026-01-10', total: 189.00, status: 'Delivered', items: 2 },
  { id: 'ORD-001229', customer: 'David Martinez', date: '2026-01-10', total: 345.50, status: 'Shipped', items: 4 },
  { id: 'ORD-001228', customer: 'Jennifer Garcia', date: '2026-01-09', total: 127.75, status: 'Processing', items: 2 },
  { id: 'ORD-001227', customer: 'Robert Lee', date: '2026-01-09', total: 95.00, status: 'Canceled', items: 1 },
  { id: 'ORD-001226', customer: 'Amanda White', date: '2026-01-08', total: 278.90, status: 'Delivered', items: 3 },
  { id: 'ORD-001225', customer: 'Christopher Hall', date: '2026-01-08', total: 156.25, status: 'Pending', items: 2 },
];

export function OrdersPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);

  const updateOrderStatus = (orderId: string, newStatus: Order['status']) => {
    setOrders(orders.map(order => 
      order.id === orderId ? { ...order, status: newStatus } : order
    ));
  };

  const filteredOrders = orders.filter((order) => {
    const matchesSearch = 
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || order.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'Delivered':
        return 'bg-green-100 text-green-700';
      case 'Shipped':
        return 'bg-blue-100 text-blue-700';
      case 'Processing':
        return 'bg-yellow-100 text-yellow-700';
      case 'Pending':
        return 'bg-gray-100 text-gray-700';
      case 'Canceled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl text-gray-900">Order Management</h1>
          <p className="text-gray-500 mt-1">Track and manage customer orders</p>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 mb-6">
        <div className="p-4 border-b border-gray-200">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search by order ID or customer name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#116E33]"
              />
            </div>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#116E33]"
            >
              <option value="all">All Status</option>
              <option value="Pending">Pending</option>
              <option value="Processing">Processing</option>
              <option value="Shipped">Shipped</option>
              <option value="Delivered">Delivered</option>
              <option value="Canceled">Canceled</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Order ID</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Customer Name</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Date</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Items</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Total</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Status</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-900">#{order.id}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">{order.customer}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {new Date(order.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{order.items}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">${order.total.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-2 py-1 text-xs rounded-full ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button 
                        className="flex items-center gap-1 px-3 py-1.5 text-sm text-gray-700 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                        View Details
                      </button>
                      
                      <div className="relative">
                        <select
                          value={order.status}
                          onChange={(e) => updateOrderStatus(order.id, e.target.value as Order['status'])}
                          className="px-3 py-1.5 text-sm border border-gray-300 rounded bg-white text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-[#116E33] appearance-none pr-8"
                        >
                          <option value="Pending">Pending</option>
                          <option value="Processing">Processing</option>
                          <option value="Shipped">Shipped</option>
                          <option value="Delivered">Delivered</option>
                          <option value="Canceled">Canceled</option>
                        </select>
                        <ChevronDown className="w-4 h-4 absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredOrders.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-gray-500">No orders found matching your filters.</p>
          </div>
        )}
      </div>

      <div className="flex justify-between items-center text-sm text-gray-500">
        <p>Showing {filteredOrders.length} of {orders.length} orders</p>
        <div className="flex gap-2">
          <button className="px-3 py-1.5 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
            Previous
          </button>
          <button className="px-3 py-1.5 bg-[#116E33] text-white rounded hover:bg-[#0d5527] transition-colors">
            1
          </button>
          <button className="px-3 py-1.5 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
            2
          </button>
          <button className="px-3 py-1.5 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
            3
          </button>
          <button className="px-3 py-1.5 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
