import { useState } from 'react';
import { Search, Plus, Edit2, Trash2, ChevronRight, ChevronDown } from 'lucide-react';

interface SubCategory {
  id: string;
  name: string;
  productCount: number;
}

interface Category {
  id: string;
  name: string;
  productCount: number;
  subCategories: SubCategory[];
  expanded: boolean;
}

const mockCategories: Category[] = [
  {
    id: 'C001',
    name: 'Dresses',
    productCount: 156,
    expanded: false,
    subCategories: [
      { id: 'SC001', name: 'Maxi Dresses', productCount: 45 },
      { id: 'SC002', name: 'Midi Dresses', productCount: 62 },
      { id: 'SC003', name: 'Mini Dresses', productCount: 49 },
    ],
  },
  {
    id: 'C002',
    name: 'Tops',
    productCount: 243,
    expanded: false,
    subCategories: [
      { id: 'SC004', name: 'Blouses', productCount: 78 },
      { id: 'SC005', name: 'T-Shirts', productCount: 95 },
      { id: 'SC006', name: 'Tank Tops', productCount: 70 },
    ],
  },
  {
    id: 'C003',
    name: 'Pants',
    productCount: 189,
    expanded: false,
    subCategories: [
      { id: 'SC007', name: 'Jeans', productCount: 98 },
      { id: 'SC008', name: 'Trousers', productCount: 56 },
      { id: 'SC009', name: 'Leggings', productCount: 35 },
    ],
  },
  {
    id: 'C004',
    name: 'Accessories',
    productCount: 124,
    expanded: false,
    subCategories: [
      { id: 'SC010', name: 'Bags', productCount: 47 },
      { id: 'SC011', name: 'Jewelry', productCount: 53 },
      { id: 'SC012', name: 'Belts', productCount: 24 },
    ],
  },
  {
    id: 'C005',
    name: 'Shoes',
    productCount: 167,
    expanded: false,
    subCategories: [
      { id: 'SC013', name: 'Heels', productCount: 62 },
      { id: 'SC014', name: 'Flats', productCount: 58 },
      { id: 'SC015', name: 'Boots', productCount: 47 },
    ],
  },
];

export function CategoriesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState<Category[]>(mockCategories);

  const toggleCategory = (categoryId: string) => {
    setCategories(categories.map(cat => 
      cat.id === categoryId ? { ...cat, expanded: !cat.expanded } : cat
    ));
  };

  const filteredCategories = categories.filter((category) => {
    const matchesSearch = category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      category.subCategories.some(sub => sub.name.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSearch;
  });

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl text-gray-900">Category Management</h1>
          <p className="text-gray-500 mt-1">Organize your product categories and sub-categories</p>
        </div>

        <button className="flex items-center gap-2 px-4 py-2 bg-[#116E33] text-white rounded-lg hover:bg-[#0d5527] transition-colors">
          <Plus className="w-5 h-5" />
          Add New Category
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search categories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#116E33]"
            />
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {filteredCategories.map((category) => (
            <div key={category.id}>
              <div className="flex items-center px-6 py-4 hover:bg-gray-50">
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="p-1 hover:bg-gray-200 rounded transition-colors mr-3"
                >
                  {category.expanded ? (
                    <ChevronDown className="w-5 h-5 text-gray-600" />
                  ) : (
                    <ChevronRight className="w-5 h-5 text-gray-600" />
                  )}
                </button>

                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm text-gray-900">{category.name}</h3>
                      <p className="text-xs text-gray-500 mt-1">
                        {category.productCount} products • {category.subCategories.length} sub-categories
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <button className="flex items-center gap-1 px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-100 rounded transition-colors">
                        <Plus className="w-4 h-4" />
                        Add Sub-category
                      </button>
                      <button className="p-2 text-gray-600 hover:bg-gray-100 rounded transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {category.expanded && (
                <div className="bg-gray-50">
                  {category.subCategories.map((subCategory) => (
                    <div
                      key={subCategory.id}
                      className="flex items-center justify-between px-6 py-3 ml-12 border-l-2 border-[#116E33] hover:bg-gray-100"
                    >
                      <div>
                        <h4 className="text-sm text-gray-900">{subCategory.name}</h4>
                        <p className="text-xs text-gray-500 mt-1">{subCategory.productCount} products</p>
                      </div>

                      <div className="flex gap-2">
                        <button className="p-2 text-gray-600 hover:bg-gray-200 rounded transition-colors">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-red-600 hover:bg-red-100 rounded transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredCategories.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-gray-500">No categories found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}
