
  # E-commerce Admin Dashboard Design

  This is a code bundle for E-commerce Admin Dashboard Design. The original project is available at https://www.figma.com/design/oy1zVm2oymyvjS16P5rAPK/E-commerce-Admin-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  