import { useState } from 'react';
import { Header } from './components/Header';
import { MegaMenu } from './components/MegaMenu';
import { Hero } from './components/Hero';
import { CategoryLanding } from './components/CategoryLanding';
import { ProductGrid } from './components/ProductGrid';
import { MiniCart } from './components/MiniCart';
import { CheckoutPage } from './components/CheckoutPage';
import { LoginModal } from './components/LoginModal';

export interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
}

export interface CartItem extends Product {
  quantity: number;
}

const products: Product[] = [
  {
    id: 1,
    name: "Elegant Evening Dress",
    price: 299,
    image: "https://images.unsplash.com/photo-1557161622-5f50ca344787?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZHJlc3MlMjBmYXNoaW9ufGVufDF8fHx8MTc2ODA2Nzc1NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Dresses"
  },
  {
    id: 2,
    name: "Designer Wool Coat",
    price: 489,
    image: "https://images.unsplash.com/photo-1755214832310-074c4cc45372?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMGNvYXQlMjBmYXNoaW9ufGVufDF8fHx8MTc2ODE4NDQwOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Outerwear"
  },
  {
    id: 3,
    name: "Luxury Cashmere Sweater",
    price: 259,
    image: "https://images.unsplash.com/photo-1766558305036-41c4e84a6379?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBzd2VhdGVyJTIwY2xvdGhpbmd8ZW58MXx8fHwxNzY4MTg1NjIyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Knitwear"
  },
  {
    id: 4,
    name: "Tailored Trousers",
    price: 189,
    image: "https://images.unsplash.com/photo-1721917113663-a4f26e197132?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMHBhbnRzJTIwdHJvdXNlcnN8ZW58MXx8fHwxNzY4MTg1NjIyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Bottoms"
  },
  {
    id: 5,
    name: "Classic Silk Blazer",
    price: 399,
    image: "https://images.unsplash.com/flagged/photo-1553802922-e345434156e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwYmxhemVyJTIwamFja2V0fGVufDF8fHx8MTc2ODE4NTYyM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Blazers"
  },
  {
    id: 6,
    name: "Signature Evening Dress",
    price: 349,
    image: "https://images.unsplash.com/photo-1557161622-5f50ca344787?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZHJlc3MlMjBmYXNoaW9ufGVufDF8fHx8MTc2ODA2Nzc1NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Dresses"
  },
  {
    id: 7,
    name: "Premium Leather Jacket",
    price: 599,
    image: "https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZW4lMjBmYXNoaW9uJTIwamFja2V0fGVufDF8fHx8MTc2ODE0NjMwMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Jackets"
  },
  {
    id: 8,
    name: "Designer Handbag",
    price: 449,
    image: "https://images.unsplash.com/photo-1575201046471-082b5c1a1e79?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwYWNjZXNzb3JpZXMlMjBsdXh1cnl8ZW58MXx8fHwxNzY4MTMyMzMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Accessories"
  }
];

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isMiniCartOpen, setIsMiniCartOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [currentView, setCurrentView] = useState<'home' | 'checkout'>('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const addToCart = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });
    setIsMiniCartOpen(true);
  };

  const removeFromCart = (productId: number) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const proceedToCheckout = () => {
    setCurrentView('checkout');
    setIsMiniCartOpen(false);
  };

  const continueShopping = () => {
    setCurrentView('home');
  };

  const handleLogin = (email: string, password: string) => {
    // Mock login - in real app would validate credentials
    setIsLoggedIn(true);
    setIsLoginModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header
        cartCount={getTotalItems()}
        onCartClick={() => setIsMiniCartOpen(true)}
        onLoginClick={() => setIsLoginModalOpen(true)}
        isLoggedIn={isLoggedIn}
      />
      
      <MegaMenu />
      
      {currentView === 'home' ? (
        <>
          <Hero />
          <CategoryLanding />
          <ProductGrid products={products} onAddToCart={addToCart} />
        </>
      ) : (
        <CheckoutPage
          cart={cart}
          totalPrice={getTotalPrice()}
          onContinueShopping={continueShopping}
        />
      )}

      <MiniCart
        isOpen={isMiniCartOpen}
        onClose={() => setIsMiniCartOpen(false)}
        cart={cart}
        onRemoveItem={removeFromCart}
        onUpdateQuantity={updateQuantity}
        totalPrice={getTotalPrice()}
        onCheckout={proceedToCheckout}
      />

      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLogin={handleLogin}
      />
    </div>
  );
}
