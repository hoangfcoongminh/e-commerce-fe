import { useState } from 'react';
import { ChevronRight } from 'lucide-react';

interface Category {
  name: string;
  subcategories: string[];
}

const categories: Category[] = [
  {
    name: 'Men',
    subcategories: ['Jackets', 'T-Shirts', 'Pants', 'Suits', 'Shoes', 'Accessories']
  },
  {
    name: 'Women',
    subcategories: ['Dresses', 'Tops', 'Bottoms', 'Outerwear', 'Shoes', 'Handbags']
  },
  {
    name: 'Accessories',
    subcategories: ['Bags', 'Watches', 'Jewelry', 'Belts', 'Sunglasses', 'Scarves']
  },
  {
    name: 'Kids',
    subcategories: ['Boys', 'Girls', 'Infants', 'Shoes', 'Accessories']
  }
];

export function MegaMenu() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  return (
    <nav className="relative bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-8 h-14">
          {categories.map((category) => (
            <div
              key={category.name}
              className="relative"
              onMouseEnter={() => setActiveCategory(category.name)}
              onMouseLeave={() => setActiveCategory(null)}
            >
              <button className="flex items-center gap-1 text-gray-700 hover:text-[#116E33] transition-colors py-4">
                <span>{category.name}</span>
                <ChevronRight className="w-4 h-4 rotate-90" />
              </button>

              {/* Mega Menu Dropdown */}
              {activeCategory === category.name && (
                <div className="absolute top-full left-0 pt-2 z-40">
                  <div className="bg-white rounded-lg shadow-xl border border-gray-200 p-6 min-w-[240px]">
                    <h3 className="text-sm uppercase tracking-wider text-gray-500 mb-4">
                      {category.name}
                    </h3>
                    <ul className="space-y-2">
                      {category.subcategories.map((subcategory) => (
                        <li key={subcategory}>
                          <button className="text-gray-700 hover:text-[#116E33] hover:translate-x-1 transition-all duration-200 block w-full text-left">
                            {subcategory}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Backdrop */}
      {activeCategory && (
        <div className="fixed inset-0 bg-black/10 z-30 pointer-events-none" />
      )}
    </nav>
  );
}
