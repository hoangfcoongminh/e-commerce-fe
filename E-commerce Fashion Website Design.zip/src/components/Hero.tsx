import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative h-[600px] bg-gray-900 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1619384259054-ee3ce9d1798c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbW9kZWwlMjBlbGVnYW50fGVufDF8fHx8MTc2ODE1MjgwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Fashion model"
          className="w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-center h-full max-w-xl">
          <h2 className="text-5xl sm:text-6xl text-white mb-6 tracking-tight leading-tight">
            Timeless Elegance
          </h2>
          <p className="text-xl text-gray-200 mb-10 leading-relaxed">
            Discover our curated collection of premium fashion pieces designed for the modern connoisseur.
          </p>
          <button
            className="group flex items-center gap-3 px-8 py-4 text-white rounded-lg transition-all hover:shadow-2xl hover:scale-105 w-fit"
            style={{ backgroundColor: '#116E33' }}
          >
            <span className="text-lg">Shop Now</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}