
  # E-commerce Fashion Website Design

  This is a code bundle for E-commerce Fashion Website Design. The original project is available at https://www.figma.com/design/1kb9b6RjFVlGPeCYVHR34C/E-commerce-Fashion-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  